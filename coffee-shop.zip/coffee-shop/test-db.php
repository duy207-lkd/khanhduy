<?php
require_once __DIR__ . '/config/init.php';
header('Content-Type: text/plain; charset=utf-8');
print_r(db()->fetchAll("SELECT staff_id, username, role FROM staff"));